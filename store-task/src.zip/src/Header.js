import React from "react";
import "./index.css";

export default function Header(props) {
  return (
    <table>
      <thead>
        <th>Name</th>
        <th>Price</th>
      </thead>
    </table>
  );
}
