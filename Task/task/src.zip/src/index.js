import React from "react";
import ReactDOM from "react-dom";
import "./Mycss.css";
import App from "./App2";

ReactDOM.render(<App />, document.getElementById("root"));
